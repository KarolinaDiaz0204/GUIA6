﻿using System;

namespace GUIA6
{
    public abstract class Servicio
    {
        public abstract void RealizarServicio();
        public abstract double CalcularCosto();

    }
}
